import React, { useState } from "react";
import { CoinbaseWalletSDK } from "@coinbase/wallet-sdk";
import { ethers } from "ethers";

const APP_NAME = "My Base Mini App";
const APP_LOGO_URL = "https://base.org/favicon.ico";
const DEFAULT_ETH_JSONRPC_URL = process.env.REACT_APP_BASE_RPC;
const DEFAULT_CHAIN_ID = Number(process.env.REACT_APP_CHAIN_ID);

function App() {
  const [account, setAccount] = useState(null);
  const [balance, setBalance] = useState(null);

  const connectWallet = async () => {
    try {
      const coinbaseWallet = new CoinbaseWalletSDK({
        appName: APP_NAME,
        appLogoUrl: APP_LOGO_URL,
        darkMode: false,
      });
      const ethereum = coinbaseWallet.makeWeb3Provider(
        DEFAULT_ETH_JSONRPC_URL,
        DEFAULT_CHAIN_ID
      );
      const provider = new ethers.BrowserProvider(ethereum);
      const accounts = await ethereum.request({ method: "eth_requestAccounts" });
      setAccount(accounts[0]);
      const bal = await provider.getBalance(accounts[0]);
      setBalance(ethers.formatEther(bal));
    } catch (err) {
      console.error("Wallet connection failed:", err);
    }
  };

  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>🚀 Base + Coinbase Wallet Mini App</h1>
      {account ? (
        <>
          <p>Connected: <b>{account}</b></p>
          <p>Balance: <b>{balance} ETH</b></p>
        </>
      ) : (
        <button onClick={connectWallet}>Connect Coinbase Wallet</button>
      )}
    </div>
  );
}

export default App;
