# My Base Mini App 🚀

This is a simple React + Coinbase Wallet + Base Mainnet mini app.

## 🧠 Features
- Connects to Coinbase Wallet on Base mainnet
- Displays user account & ETH balance
- 100% free to build & host (no backend)

## ⚙️ Setup

```bash
npm install
npm start
```

## 🌐 Deploy to Vercel
```bash
npm run build
npx vercel deploy --prod
```

Then open your deployed URL inside Coinbase Wallet → Mini Apps → Add custom app.
